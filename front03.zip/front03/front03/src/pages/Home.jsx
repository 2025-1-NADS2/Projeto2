export default function Home(){
    return(
        <div>
            <h1>Home</h1>
            <p>Bem Vindo a minha aplicação web!</p>
        </div>
    )
}