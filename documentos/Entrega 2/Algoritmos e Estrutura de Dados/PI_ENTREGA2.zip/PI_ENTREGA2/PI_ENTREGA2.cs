﻿using System;

namespace PI_ENTREGA2
{
    public class Atividade
    {
        public string Nome { get; set; }
        public string Descricao { get; set; }
    }

    public class Participante
    {
        public string Nome { get; set; }
        public string Email { get; set; }
    }

    public class Palestrante
    {
        public string Nome { get; set; }
        public string Titulo { get; set; }
    }

    public class Evento
    {
        public string Nome { get; set; }
        public Atividade[] Atividades { get; set; }
        public Participante[] Participantes { get; set; }
        public Palestrante[] Palestrantes { get; set; }

        public Evento(string nome, int qtdAtividades, int qtdParticipantes, int qtdPalestrantes)
        {
            Nome = nome;
            Atividades = new Atividade[qtdAtividades];
            Participantes = new Participante[qtdParticipantes];
            Palestrantes = new Palestrante[qtdPalestrantes];
        }
    }

    internal class PI_ENTREGA2
    {
        static void ImprimirItensEvento(Evento evento)
        {
            Console.WriteLine($"\nEvento: {evento.Nome}");
            Console.WriteLine("Atividades:");
            foreach (var atividade in evento.Atividades)
            {
                if (atividade != null)
                {
                    Console.WriteLine($"- {atividade.Nome}: {atividade.Descricao}");
                }
            }

            Console.WriteLine("Participantes:");
            foreach (var participante in evento.Participantes)
            {
                if (participante != null)
                {
                    Console.WriteLine($"- {participante.Nome} ({participante.Email})");
                }
            }

            Console.WriteLine("Palestrantes:");
            foreach (var palestrante in evento.Palestrantes)
            {
                if (palestrante != null)
                {
                    Console.WriteLine($"- {palestrante.Nome} ({palestrante.Titulo})");
                }
            }

            Console.WriteLine("=====================");
        }

        static Evento BuscarEvento(Evento[] lista, string nome)
        {
            foreach (var evento in lista)
            {
                if (evento != null && evento.Nome.Equals(nome, StringComparison.OrdinalIgnoreCase))
                {
                    return evento;
                }
            }
            return null;
        }

        static void Main(string[] args)
        {
            Evento[] eventos = new Evento[3];

            eventos[0] = new Evento("Tech Conference", 2, 2, 1);
            eventos[0].Atividades[0] = new Atividade { Nome = "Workshop de IA", Descricao = "Introdução à IA" };
            eventos[0].Atividades[1] = new Atividade { Nome = "Cloud", Descricao = "Computação em nuvem" };
            eventos[0].Participantes[0] = new Participante { Nome = "Ana", Email = "ana@exemplo.com" };
            eventos[0].Participantes[1] = new Participante { Nome = "João", Email = "joao@exemplo.com" };
            eventos[0].Palestrantes[0] = new Palestrante { Nome = "Dr. Smith", Titulo = "Especialista em Cloud" };

            eventos[1] = new Evento("Web Dev Summit", 1, 1, 1);
            eventos[1].Atividades[0] = new Atividade { Nome = "React Avançado", Descricao = "Hooks e performance" };
            eventos[1].Participantes[0] = new Participante { Nome = "Carlos", Email = "carlos@exemplo.com" };
            eventos[1].Palestrantes[0] = new Palestrante { Nome = "Prof. Oliveira", Titulo = "Desenvolvedor Web" };

            eventos[2] = new Evento("Data Science Expo", 2, 2, 1);
            eventos[2].Atividades[0] = new Atividade { Nome = "Big Data", Descricao = "Volume de dados" };
            eventos[2].Atividades[1] = new Atividade { Nome = "Python para Dados", Descricao = "Análise com Pandas" };
            eventos[2].Participantes[0] = new Participante { Nome = "Beatriz", Email = "bia@exemplo.com" };
            eventos[2].Participantes[1] = new Participante { Nome = "Felipe", Email = "felipe@exemplo.com" };
            eventos[2].Palestrantes[0] = new Palestrante { Nome = "Dra. Clara", Titulo = "Cientista de Dados" };

            string input;
            do
            {
                Console.WriteLine("\nDigite o nome do evento que deseja buscar ('todos' para listar todos, 'sair' para encerrar):");
                input = Console.ReadLine();

                if (input.Equals("todos", StringComparison.OrdinalIgnoreCase))
                {
                    foreach (var evento in eventos)
                    {
                        if (evento != null)
                        {
                            ImprimirItensEvento(evento);
                        }
                    }
                }
                else if (!input.Equals("sair", StringComparison.OrdinalIgnoreCase))
                {
                    Evento resultado = BuscarEvento(eventos, input);
                    if (resultado != null)
                    {
                        ImprimirItensEvento(resultado);
                    }
                    else
                    {
                        Console.WriteLine("Evento não encontrado.");
                    }
                }

            } while (!input.Equals("sair", StringComparison.OrdinalIgnoreCase));

            Console.WriteLine("Programa encerrado.");
        }
    }
}
