export const data = [
  {
    title: "Educação",
    description:
      "Oferecemos cursos e oficinas para capacitar jovens e adultos.",
  },
  {
    title: "Cultura",
    description: "Promovemos eventos culturais para enriquecer a comunidade.",
  },
  {
    title: "Sustentabilidade",
    description: "Iniciativas que visam a preservação do meio ambiente.",
  },
];
