﻿using System;
using System.Collections.Generic;

namespace SistemaCadastroEventosIC
{
    // Classe representando um evento
    public class Evento
    {
        //gets e sets simplificados
        public int Id { get; set; }
        public string Nome { get; set; }
        public DateTime Data { get; set; }
        public string Local { get; set; }

        public override string ToString()
        {
            return $"ID: {Id}, Nome: {Nome}, Data: {Data.ToShortDateString()}, Local: {Local}";
        }
    }

    // Classe para gerenciamento de eventos (recebimento e envio de dados)
    public class GerenciadorEventos
    {
        private readonly List<Evento> _eventos;

        public GerenciadorEventos()
        {
            _eventos = new List<Evento>();
        }

        // Método para cadastrar um evento
        public void CadastrarEvento(Evento evento)
        {
            _eventos.Add(evento);
            Console.WriteLine("Evento cadastrado com sucesso!");
        }

        // Método para listar eventos
        public void ListarEventos()
        {
            Console.WriteLine("Lista de Eventos:");
            foreach (var evento in _eventos)
            {
                Console.WriteLine(evento);
            }
        }
    }

    // Classe principal onde gerencia as interações
    public class SistemaCentral
    {
        private readonly GerenciadorEventos _gerenciadorEventos;

        public SistemaCentral()
        {
            _gerenciadorEventos = new GerenciadorEventos();
        }

        public void Executar()
        {
            Console.WriteLine("Bem-vindo ao Sistema de Cadastro de Eventos do Instituto Criativo!");

            while (true)
            {
                Console.WriteLine("\nOpcoes:");
                Console.WriteLine("1 - Cadastrar Evento");
                Console.WriteLine("2 - Listar Eventos");
                Console.WriteLine("3 - Sair");
                Console.Write("Escolha uma opção: ");

                string opcao = Console.ReadLine();

                switch (opcao)
                {
                    case "1":
                        CadastrarEvento();
                        break;
                    case "2":
                        _gerenciadorEventos.ListarEventos();
                        break;
                    case "3":
                        Console.WriteLine("Saindo do sistema");
                        return;
                    default:
                        Console.WriteLine("Opção inválida. Tente novamente.");
                        break;
                }
            }
        }

        private void CadastrarEvento()
        {
            Console.WriteLine("\nCadastro de Evento:");

            Console.Write("Digite o ID do evento: ");
            int id = int.Parse(Console.ReadLine());

            Console.Write("Digite o nome do evento: ");
            string nome = Console.ReadLine();

            Console.Write("Digite a data do evento (yyyy-mm-dd): ");
            DateTime data = DateTime.Parse(Console.ReadLine());

            Console.Write("Digite o local do evento: ");
            string local = Console.ReadLine();

            var evento = new Evento
            {
                Id = id,
                Nome = nome,
                Data = data,
                Local = local
            };

            _gerenciadorEventos.CadastrarEvento(evento);
        }
    }

    // Ponto de entrada do programa
    class Program
    {
        static void Main(string[] args)
        {
            SistemaCentral sistema = new SistemaCentral();
            sistema.Executar();
        }
    }
}
